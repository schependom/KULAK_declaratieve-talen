/*
    ONE-PASS TRANSLATION
*/

/*

    ?- vertaal([def(a), gebr(a), gebr(b), gebr(c), def(c), def(b)], L).
        L = [stel(a,1), gebr(1), gebr(3), gebr(2), stel(c, 2), stel(b, 3)].

    TIP2

    ?- member(1-X, [_ | _]).
        true.

    TIP3

    ?- L=[_ | _],member(1-X,L),X=a.
        L = [1-a|_],
        X = a ;
        L = [_, 1-a|_],
        X = a ;
        L = [_, _, 1-a|_],
        X = a ;
        L = [_, _, _, 1-a|_],
        X = a ;
        L = [_, _, _, _, 1-a|_],

    ?- L=[_ | _],member(1-X,L).
        L = [1-X|_] ;
        L = [_, 1-X|_] .
*/



vertaal(Invoer, L) :-
    vertaal(Invoer, L, 1, [_ | _]).

vertaal([], L, _, _).

vertaal([gebr(Head) | Tail], L, Counter, SymboolTabel) :-
    member(NewCounter-Head, SymboolTabel), !,
    NewL = [ gebr(NewCounter) | L ],
    vertaal(Tail, NewL, Counter, SymboolTabel).

vertaal([gebr(Head) | Tail], L, Counter, SymboolTabel) :-
    \+ member(Counter-Head, SymboolTabel), !,
    member(AndereCounter-Head, SymboolTabel), !,
    NewL = [ gebr(AndereCounter) | L ],
    vertaal(Tail, NewL, Counter, SymboolTabel).


vertaal([def(Head) | Tail], L, Counter, SymboolTabel) :-
    NewL = [stel(Head, Counter) | L], !,
    member(Counter-Head, SymboolTabel), !,
    succ(Counter, NewCounter),
    vertaal(Tail, NewL, NewCounter, SymboolTabel).

